package com.pronotate.stepdefinitions;

import java.io.IOException;
import java.util.List;
import java.util.Map;

import org.apache.poi.openxml4j.exceptions.InvalidFormatException;
import org.openqa.selenium.support.PageFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;

import com.pronotate.commonutils.Constatntvalue;
import com.pronotate.commonutils.ExcelReader;
import com.pronotate.commonutils.webdrivermanager;

import io.cucumber.java.en.Given;
import io.cucumber.java.en.Then;
import io.cucumber.java.en.When;

public class Loginstepdefinitions {

	@Autowired
	private com.pronotate.pageelements.LoginPageElements LoginPageElements;

	@Autowired
	private webdrivermanager webdriver;

	@Autowired
	private Constatntvalue constantvalue;

	@Autowired
	private ExcelReader reader;

	@Given("Navigate to the Pronotate Portal URL")
	public void navigate_to_the_pronotate_portal_url() {

		webdriver.getDriver().get("https://uat.pronotate.com/projects/login");
		PageFactory.initElements(webdriver.getDriver(), com.pronotate.pageelements.LoginPageElements.class);
	}

	@When("We enter Login Credentials in sheetname {string} and row indewx {int}")
	public void we_enter_login_credentials_in_sheetname_and_row_indewx(String sheetname, Integer rowindex) {

		try {			
			System.out.println("Before");
			List<Map<String, String>> data = reader.getData(Constatntvalue.Logindatapath1, sheetname);
			System.out.println("Enter ");
			LoginPageElements.getUserName().sendKeys(data.get(rowindex).get("Username"));
			LoginPageElements.getPassword().sendKeys(data.get(rowindex).get("Password"));
		} catch (InvalidFormatException | IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}
 
	@Then("Click login button")
	public void click_login_button() {

	}

	@Then("Verify that login validations in sheetname {string} and row indewx {int}")
	public void verify_that_login_validations_in_sheetname_and_row_indewx(String string, Integer int1) {

	}

}
