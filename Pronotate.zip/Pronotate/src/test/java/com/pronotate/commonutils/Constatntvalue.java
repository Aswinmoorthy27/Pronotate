package com.pronotate.commonutils;

import java.io.IOException;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;
import org.testng.annotations.DataProvider;

@Component
public class Constatntvalue {

	public static String Appurl = "https://uat.pronotate.com/projects/login";

	public static String ChromeBrowser = "Chrome";
	public static String FireFoxBrowser = "Firefox";
	public static String IEBrowser = "Edge";
	public static String Logindatapath1 = "src/main/resources/Testdata/Login_Datas1.xlsx";

	public static String Logindatapath = "src/main/resources/Testdata/Login_Datas.xlsx";

}
