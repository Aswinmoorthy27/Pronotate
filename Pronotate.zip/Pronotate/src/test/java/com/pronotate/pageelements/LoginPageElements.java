package com.pronotate.pageelements;

import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.How;
import org.springframework.stereotype.Component;

@Component
public class LoginPageElements {
	
	@FindBy(name = "email")
	private static WebElement UserName;
	
	@FindBy(name = "password")
	private static WebElement Password;
	
	
	@FindBy(xpath = "//button[text()='Login']")
	private static WebElement Login;
	
	
	public WebElement getUserName() {
		return UserName;
	}

	public WebElement getPassword() {
		return Password;
	}

	public WebElement getLogin() {
		return Login;
	}
	
	
}
