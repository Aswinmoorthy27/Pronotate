package com.pronotate.runners;

import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;
import org.testng.annotations.BeforeTest;

import com.pronotate.commonutils.Constatntvalue;
import com.pronotate.commonutils.ExcelReader;

import io.cucumber.junit.Cucumber;
import io.cucumber.junit.CucumberOptions;


@RunWith(Cucumber.class)
@CucumberOptions(features = "src/main/resources/Features", glue = "com.pronotate.stepdefinitions")
public class LoginRunner {

}
